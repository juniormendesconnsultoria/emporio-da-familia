EMPÓRIO DA FAMÍLIA — SITE

Arquivos:
- index.html
- style.css
- script.js
- assets/ (imagens enviadas)

O site é estático e responsivo. Pode ser publicado gratuitamente em GitHub Pages, Netlify ou Cloudflare Pages.

Antes de publicar, recomendamos completar:
- WhatsApp
- endereço
- cidade/UF
- Instagram/Facebook, se houver
- fotos reais do estabelecimento
- eventual logo oficial em alta resolução
